## [1.0.1](https://github.com/RouHim/ez-books/compare/v1.0.0...v1.0.1) (2025-12-27)


### Bug Fixes

* **ci:** read version from .version file instead of git ls-remote ([006c48f](https://github.com/RouHim/ez-books/commit/006c48f6c54297d62d235afa4599af9514d1ca4f))

# 1.0.0 (2025-12-27)


### Features

* add semantic-release configuration ([91fe94b](https://github.com/RouHim/ez-books/commit/91fe94b1f705c43d696c331723d4ac3eb5d62d65))
