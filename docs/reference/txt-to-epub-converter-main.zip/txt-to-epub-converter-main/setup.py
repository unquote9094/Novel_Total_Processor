"""
Setup script for txt-to-epub-converter
"""
from setuptools import setup

# Use pyproject.toml for configuration
setup()
